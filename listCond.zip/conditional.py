'''
conditional statement
    =>conditional oprator
            > Greater then
            < Less Then
            >=Greater then Equal
            <=Less Then equal
            == equal(Note "=" assigin oprator)
            ! not
            != not Equal
    if
    if else
    nested if else
    loop
        for
        while
        do while(Which is not supported  by python)

// for only True condition
if condition:
    true part

//if both/either condition true and false

if condition:
    true part
else:
   false part

'''
#for only True condition
if 20>10 :
    print("yes 20 is greater then 10")


#if both/either condition true and false
if 10>20:
    print("yes")
else:
    print("No")


age=int(input("Please enter Your Age:- "))

if age>18:
    print("You Are Eligible for Vote")
else:
    print("wo ho You Are not Eligible for Vote please try after some time")


























    

            
